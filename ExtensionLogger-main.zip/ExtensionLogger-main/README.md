# ExtensionLogger
                                                                                                 
How to Download-                                                                                   
                                                                                                  
Step 1: Click CODE Right Here ![Inkedef857ff6c7957bb7d8f4c7ca9378ed0b](https://user-images.githubusercontent.com/116574168/198856684-736232b8-7645-46c4-abdb-7e4babe18538.jpg)

Step 2: Click Download ZIP

Step 3: Extract File

Step 4: DONE

HOW TO USE?

Tutorial - https://www.youtube.com/watch?v=lcfdhsNiiMI
